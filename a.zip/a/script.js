window.onload = function() {
    setTimeout(function() {
        document.getElementById('splash-screen').style.display = 'none';
        document.getElementById('content').style.display = 'block';
        setTimeout(function() {
            document.getElementById('content').style.opacity = '1'; // İçeriğin solukluktan normale geçmesini sağlar
        }, 50);
    }, 3000); // Display splash screen for 3 seconds
};
document.querySelectorAll('.navbar ul li a').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault(); // Varsayılan tıklama olayını durdur
        
        const targetId = this.getAttribute('href'); // Hedef bölümün id'sini al
        const targetSection = document.querySelector(targetId); // Hedef bölümü seç

        // Hedef bölüme yavaşça kaydır
        targetSection.scrollIntoView({
            behavior: 'smooth' // Kaydırma davranışını yumuşak yap
        });
    });
});
const elts = {
    text1: document.getElementById("text1"),
    text2: document.getElementById("text2")
};

const texts = [
    "",
    "",
    "",
    "Hoşgeldin",
    "Biz burada",
    "Oyun",
    "Yazılım",
    "Ve",
    "Tasarım",
    "yapıyoruz",
    "sende bize katıl"
];

const paddings = [
    "10px",
    "15px",
    "20px",
    "25px",
    "30px",
    "35px",
    "40px",
    "45px"
];

const morphTime = 1;
const cooldownTime = 0.25;

let textIndex = texts.length - 1;
let time = new Date();
let morph = 0;
let cooldown = cooldownTime;

elts.text1.textContent = texts[textIndex % texts.length];
elts.text2.textContent = texts[(textIndex + 1) % texts.length];

function doMorph() {
    morph -= cooldown;
    cooldown = 0;

    let fraction = morph / morphTime;

    if (fraction > 1) {
        cooldown = cooldownTime;
        fraction = 1;
    }

    setMorph(fraction);
}

function setMorph(fraction) {
    elts.text2.style.filter = `blur(${Math.min(8 / fraction - 8, 100)}px)`;
    elts.text2.style.opacity = `${Math.pow(fraction, 0.4) * 100}%`;
    elts.text2.style.paddingLeft = paddings[(textIndex + 1) % texts.length]; // padding-left ayarı

    fraction = 1 - fraction;
    elts.text1.style.filter = `blur(${Math.min(8 / fraction - 8, 100)}px)`;
    elts.text1.style.opacity = `${Math.pow(fraction, 0.4) * 100}%`;
    elts.text1.style.paddingLeft = paddings[textIndex % texts.length]; // padding-left ayarı

    elts.text1.textContent = texts[textIndex % texts.length];
    elts.text2.textContent = texts[(textIndex + 1) % texts.length];
}

function doCooldown() {
    morph = 0;

    elts.text2.style.filter = "";
    elts.text2.style.opacity = "100%";
    elts.text2.style.paddingLeft = paddings[(textIndex + 1) % texts.length]; // padding-left ayarı

    elts.text1.style.filter = "";
    elts.text1.style.opacity = "0%";
    elts.text1.style.paddingLeft = paddings[textIndex % texts.length]; // padding-left ayarı
}

function animate() {
    requestAnimationFrame(animate);

    let newTime = new Date();
    let shouldIncrementIndex = cooldown > 0;
    let dt = (newTime - time) / 1000;
    time = newTime;

    cooldown -= dt;

    if (cooldown <= 0) {
        if (shouldIncrementIndex) {
            textIndex++;
        }

        doMorph();
    } else {
        doCooldown();
    }
}

animate();
